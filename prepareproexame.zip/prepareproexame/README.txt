
PrepareExame (versão v2 — igual ao Canva)

Como rodar (VS Code + Live Server)
1) Abra a pasta no VS Code.
2) Instale Live Server (Ritwick Dey).
3) Clique com o direito em index.html > Open with Live Server.

O que você pediu e está pronto:
- Logo do Canva no cabeçalho (troque assets/logo.svg pelo seu SVG oficial).
- Idioma no cabeçalho (PT/ES/EN).
- Busca com ícone de lupa (sem botão Redefinir).
- Categorias (Lab, Imagem, Medicamentos) com setinha para expandir/recolher.
- Fontes iguais ao Canva: TT Ramillas (use os arquivos .ttf locais).
  Coloque em assets/fonts: TTRamillas-Regular.ttf, TTRamillas-Bold.ttf, TTRamillas-Italic.ttf.

Dicas
- Se quiser outra arte de topo, substitua hero.svg (já usamos o seu “Design do Futuro.svg” se ele estiver aqui com nome hero.svg).
- Ajuste os dados em data.js.
